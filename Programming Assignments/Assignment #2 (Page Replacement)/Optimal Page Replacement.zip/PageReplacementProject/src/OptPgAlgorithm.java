import java.util.Scanner;

public class OptPgAlgorithm {
	String refString="";
	int numFrames=0;
	int numFaults=0;
	char memoryArray[];
	int fc=0;

	Scanner scn = new Scanner(System.in);

	//Method to get user inputs for reference string and number of frames
	public void input()
	{
		System.out.println("Please enter a reference String");
		refString = scn.next();

		System.out.println("Please enter the number of frames");
		numFrames = scn.nextInt();

		memoryArray = new char[numFrames];
	}

	//Goes through the memory array and see if there is a match of the character in the array and returns true, 
	//Otherwise it returns false
	public boolean search(char ch)
	{
		for(int i=0;i<fc;i++)
		{
			char temp=memoryArray[i];
			if(temp==ch)
			{
				return true;
			}
		}
		return false;
	}

	//It returns how many indexes ahead of the current array is the next instance of the character
	public int future(char ch, int currentIndex)
	{
		int result=refString.length()+1;

		for(int i=currentIndex+1;i<refString.length();i++)
		{
			char temp=refString.charAt(i);

			if(temp==ch)
			{
				if(i<result)
				{
					result=i;
				}
			}
		}
		return result;

	}

	public void optimalReplacement()
	{
		System.out.println("Total Reference String Length is: "+ refString.length() + "\n") ;

		for(int i=0;i <refString.length();i++)
		{
			char ch=refString.charAt(i);

			if(search(ch))
			{

			}
			else
			{
				// page fault
				System.out.print("Page fault At index "+i);
				numFaults++;

				if(fc<numFrames)
				{
					memoryArray[fc]=ch;
					fc++;
				}
				else
				{

					int optimal[]=new int[numFrames];

					for(int j=0;j<numFrames;j++)
					{
						optimal[j]=future(memoryArray[j],i);
					}
					// to find the page to be replaced
					int index=0;
					int max=optimal[0];
					for(int j=1;j<numFrames;j++)
					{
						if(optimal[j]>max){
							max=optimal[j];
							index=j;
						}
					}

					// replace page
					System.out.print(" and page "+ memoryArray[index]+" is replaced by "+ch);
					memoryArray[index]=ch;

				}

				System.out.println();

			}
			
			String memoryToString = "";
			
			for(char t: memoryArray)
				memoryToString += t + " ";
			
			System.out.println(ch + ": Memory is: " + memoryToString + ": Number of Page Faults: " + numFaults + "\n");
			
		}

		System.out.println("Total Number of Page Faults is: "+numFaults);
	}

	public static void main(String args[])
	{
		OptPgAlgorithm object = new OptPgAlgorithm();
		object.input();
		object.optimalReplacement();
	}

}